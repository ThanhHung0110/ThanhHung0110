//thiết lập LCD --------------------------------------------
LiquidCrystal lcd(30, 31, 32, 33, 34, 35);

//thiết lập RFID ---------------------------------------------
#define RST_PIN         9
#define SS_PIN          53
MFRC522 mfrc522(SS_PIN, RST_PIN);

//thiết lập keypad
const byte ROWS = 4; // Số hàng của keypad
const byte COLS = 4; // Số cột của keypad

char keys[ROWS][COLS] = {
  {'1', '2', '3', 'A'},
  {'4', '5', '6', 'B'},
  {'7', '8', '9', 'C'},
  {'R', '0', '#', 'D'}
};
byte rowPins[ROWS] = {42, 43, 44, 45};    // Chân ROWs sẽ kết nối với các chân từ 42 đến 45
byte colPins[COLS] = {46, 47, 48, 49 };
Keypad keypad = Keypad(makeKeymap(keys), rowPins, colPins, ROWS, COLS);
//chọn mode-----------------------------------------------------------------------------------
int mode = 0;
#define manHinhChinh    	0
#define laySo           	1
#define docRFID         	2
#define camOn           	3
#define modeMonneyInCard 	4	
#define modeThoatDocCard  5
#define modeNhapMatKhau   6
#define modeNhapTien      7
//định nghĩa các chân
#define loa             13
#define redLed          10
#define greenLed        12
//delay để hiển thị màn hình
//----------------delay de hien thi LCD-------
unsigned long previousMillis = 0;        // will store last time LED was updated
const long interval = 500;


//Sản phẩm
uint ProductNumber[6] = {
	

	11, 12, 13, 
	21, 22, 23 
}; //35 san pham
//gia san pham
uint ProductPrice[6] = {
	

	5,		5,		5,		
	10,		8,		6	
};
int giaSanPham=0;
int sanPhamChon=0;
//thiết lập motor

//MT1  CT1
const int R1 = A0;//hang1
const int R2 = A1; //hang2
const int R3 = A2;

const int C1 = A3; 
const int C2 = A4; 
const int C3 = A5; //cot

const int CT1_PIN = 23;
const int CT2_PIN = 24;
const int CT3_PIN = 25;
#define CT1  digitalRead(CT1_PIN)
#define CT2  digitalRead(CT2_PIN)
#define CT3  digitalRead(CT3_PIN)

//Các tham số liên quan đến thẻ
MFRC522::MIFARE_Key key = { keyByte: {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF} };         //Mật khẩu thẻ

MFRC522::MIFARE_Key oldKeyA = {keyByte:{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};
MFRC522::MIFARE_Key oldKeyB = {keyByte:{0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};
// MFRC522::MIFARE_Key keyB;

MFRC522::MIFARE_Key newKeyA = {keyByte: {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};
MFRC522::MIFARE_Key newKeyB = {keyByte: {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF}};
//this is the block number we will write into and then read.
int sectorNo = 9;
int block = sectorNo * 4;
int blockIDCard = sectorNo * 4 + 1;
//byte blockcontent[16] = {"0000000000099999"};  //an array with 16 bytes to be written into one of the 64 card blocks is defined
//byte blockZero[16] = { "0000000000000000" };  //an array with 16 bytes to be written into one of the 64 card blocks is defined
byte blockZero[16] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};  //all zeros. This can be used to delete a block.
unsigned long prvCard = 0;        // will store last time LED was updated
const long intervalCard = 300;           // interval at which to blink (milliseconds)
byte readbackblock[18];
byte readbackblockPhone[18];			//số điện thoại khách hàng
byte bufferBlock[16];
String phoneKH="";
//các lệnh của card
String value;
unsigned long money;							//số tiền trong thẻ
unsigned long _naptien=0;         //số tiền cần nạp
int countToBreakHTsoTien=0; 					//thoát hàm hiển thị số tiền trong thẻ
boolean setkey_card = false;					//bit kiểm tra set key
boolean b_chophepdocCard = true;
int naptien=0;
int truongHopKhiGhiTien=0;
int am =0;

const String cm_readMoney = "D";                //lenh doc tien gui len PC
const String cm_faultCard = "F";                //lẹnh lỗi xác thực
const String cm_TruMoneyInCard = "E";           //lệnh trừ tiền trong thẻ
const String cm_CongMoneyInCard = "W";          //lệnh cộng tiền trong thẻ
//const String cm_CancelWriteMoney = "H";         //lệnh hủy trừ tiền
const String cm_confirmMinusMoneyInCard = "B";  //lẹnh đã trừ tiền trong thẻ
const String cm_confirmPlusMoneyInCard = "A";   //lẹnh đã + tiền trong thẻ
const String cm_faultWhenCommand = "N";         //lenh thuc hien bi loi
const String cm_resetAllCommand = "Z";		   //lenh nay se reset het cac lenh cua the
const String cm_setNewCard = "S";		   //lệnh này để tạo thẻ mới
const String cm_InputMobile = "I";				//so mobile