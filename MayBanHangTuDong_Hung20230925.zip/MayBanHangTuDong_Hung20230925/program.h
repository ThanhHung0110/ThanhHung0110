void KeyPad();              //chương trình đọc phím
void bip(byte _solan, long int _delay);//hàm bip loa
void displayMain();                         //các bước chạy chương trình ở đây

void hienThiManHinhChinh();             //hàm hiển thị màn hình chính    
uint SearchPosProduct(uint A[], uint x, int len);      //hàm tìm vị trí sản phẩm
void motor(int _motorSo);                   //hàm chạy motor
void DisplayThankYou();                     //hiển thị cám ơn và chạy motor
String GetNumber();
void DisplayNumber(String _num);        

int readBlock(int blockNumber, byte arrayAddress[]); //hàm đọc block để xác thực card
void hienThiSoTienTrongThe();                           //hàm hiển thị số tiền trong thẻ

int writeBlock(int blockNumber, byte arrayAddress[]);       //lệnh ghi thẻ
void thanhtoanThe();
void thoatdocCard();
void nhapMatKhau();
void nhapTien();
//Chương trình chính chạy từng bước ở đây-------------------------------------------------
void displayMain()
{
    unsigned long currentMillis = millis();
  if (currentMillis - previousMillis >= interval) {
    previousMillis = currentMillis;
        switch (mode)
        {
            case manHinhChinh:
                hienThiManHinhChinh();
            break;
            case laySo:
                GetNumber();
            break;
            case docRFID:
                thanhtoanThe();
            break;
            case camOn:
                DisplayThankYou();
            break;
            case modeMonneyInCard:
                hienThiSoTienTrongThe(); 
                break;
            case modeThoatDocCard:
                thoatdocCard();
                break;
            case modeNhapMatKhau:
                nhapMatKhau();
                break;
            case modeNhapTien:
                nhapTien();
                break;


        }
    }
}
//---------------------------------------------------------------------




//-----------Ham bip loa-------------
void bip(byte _solan, long int _delay)
{
	while (_solan--)
	{
		digitalWrite(loa, HIGH); delay(_delay);
		digitalWrite(loa, LOW); delay(_delay);
	}
}
//hàm đọc KeyPad
String num;
void KeyPad()
{
	char key = keypad.getKey();
	//GLCD.ClearScreen();
	if (key) {

		if (mode == manHinhChinh)
		{
			b_chophepdocCard=false;         //cho phép tắt đọc card
            switch (key)
			{
			    case NO_KEY:
				    break;

			    case '1': case '2': case '3': case '4':
			    //case '5': case '6': case '7': case '8':
                    bip(1, 50);
                    num = num + key;
                    mode = laySo;           //nếu nhấn số thì chuyển qua mode mua hàng
                    lcd.setCursor(0, 1);lcd.print("SP:");
                    lcd.setCursor(3, 1);
                    lcd.print(num);
                    //hien thi number
                    break;	
                    case 'A':
                    bip(1,50);                   
                    num="";
                    mode = modeNhapMatKhau;
                    b_chophepdocCard =true;             //bit cho phép đọc thẻ

                    break;
                   


			}
		}
		
    }			
}

void hienThiManHinhChinh()
{
    lcd.clear();
    lcd.setCursor(2, 0);
    lcd.print("Moi Chon San Pham");
}

String GetNumber()
{
	char key1 = keypad.getKey();
	bool b_breakgetnumber = false;
	while (key1 != 'R')
	{	

		char key1 = keypad.getKey();
		switch (key1)
		{
            case NO_KEY:
                break;

		    case '1': case '2': case '3': case '4':
		   // case '5': case '6': case '7': case '8': case 9:
                bip(1, 50);
                if (num.length() < 2)
                {
                    num = num + key1;
                    if (num.length() == 2)
                    {
                        giaSanPham = ProductPrice[SearchPosProduct(ProductNumber, num.toInt(), 6)-1];//(sizeof(ProductNumber)/sizeof(int)) - 1)];	
                        
                    }
                }
                DisplayNumber(num);
			
			break;

		    case 'C':
                bip(1, 50);
                num = "";
                lcd.clear();
                mode=manHinhChinh;
                hienThiManHinhChinh();
			
			break;
		
		    case 'R':
                bip(1, 50);
                b_breakgetnumber = true;
                
                sanPhamChon = num.toInt();

			break;
			
		    default:
			break;

		}
		
		if (b_breakgetnumber)
		{
			//mode= docRFID;

            if( sanPhamChon ==11 || sanPhamChon ==12 || sanPhamChon ==13 || sanPhamChon ==21 || sanPhamChon ==22 || sanPhamChon ==23)
                {
                     b_chophepdocCard = true;
                    naptien=1;          //2 bit này cho phép ghi số tiền
                    am=1;
                    num="";
                    mode = docRFID;

                }
                else     {mode = manHinhChinh;num="";}
			break;          //thoát lệnh while
		}
		
	}
  //int giaSanPham = ProductPrice[SearchPosProduct(ProductNumber, num.toInt(), (sizeof(ProductNumber)/sizeof(int)) - 1)-1];	
  //Serial.println(giaSanPham);
	return num;

}

//hàm tìm sản phẩm
uint SearchPosProduct(uint A[], uint x, int len)
{
	int i, pos = -1;
	for (i = 0; i < len; i++)
		if (x == A[i])
			pos = i+1;
	return pos;
}
//Hien thi so san pham
void DisplayNumber(String _num)
{
	lcd.setCursor(0, 1);lcd.print("SP:");
    lcd.setCursor(3,1);
	lcd.print(_num);

	if (_num.length() >= 2)
	{
		//giaSanPham= ProductPrice[SearchPosProduct(ProductNumber, num.toInt(), 39)-1];
		lcd.setCursor(6,1);lcd.print("Gia:");
	    lcd.setCursor(10,1);lcd.print(giaSanPham);
	    lcd.setCursor(12,1);lcd.print(".000 VND");
		
	}
	

}

void DisplayThankYou()
{
    lcd.setCursor(7,3);lcd.print("Cam On!");
    Serial.println(sanPhamChon);
    motor(sanPhamChon);
    mode = manHinhChinh;
    b_chophepdocCard = true;
}
void motor(int _motorSo) {

    switch(_motorSo)
    {
        case 11: 
            digitalWrite(R1, HIGH);
            digitalWrite(C1, HIGH);
            delay(3000);
            while (!CT1)
            {
                delay(100);
            }
            digitalWrite(R1, LOW);
            digitalWrite(C1, LOW);
        break;
        case 12: 
            digitalWrite(R1, HIGH);
            digitalWrite(C2, HIGH);
            delay(3000);
            while (!CT2)
            {
                delay(100);
            }
            digitalWrite(R1, LOW);
            digitalWrite(C2, LOW);
        break;
        case 13: 
            digitalWrite(R1, HIGH);
            digitalWrite(C3, HIGH);
            delay(3000);
            while (!CT3)
            {
                delay(100);
            }
            digitalWrite(R1, LOW);
            digitalWrite(C3, LOW);
        break;
        case 21: 
            digitalWrite(R2, HIGH);
            digitalWrite(C1, HIGH);
            delay(3000);
            while (!CT1)
            {
                delay(100);
            }
            digitalWrite(R2, LOW);
            digitalWrite(C1, LOW);
        break;
        case 22: 
            digitalWrite(R2, HIGH);
            digitalWrite(C2, HIGH);
            delay(3000);
            while (!CT2)
            {
                delay(100);
            }
            digitalWrite(R2, LOW);
            digitalWrite(C2, LOW);
        break;
        case 23: 
            digitalWrite(R2, HIGH);
            digitalWrite(C3, HIGH);
            delay(3000);
            while (!CT3)
            {
                delay(100);
            }
            digitalWrite(R2, LOW);
            digitalWrite(C3, LOW);
        break;
    }

    
}


void ActionCard()
{
   if(b_chophepdocCard)
   {
        // Xem thử có card mới hiện diện hay không
        if (!mfrc522.PICC_IsNewCardPresent()) {
            prvCard = millis();
            return;
        }
        // Nếu có thì đọc card
        if (!mfrc522.PICC_ReadCardSerial())
        {
            return;
        }
        //kiểm tra xác thực card có đúng không
        if (readBlock(block, readbackblock) != 0)   //kiem tra xac thuc
        {
            
            mfrc522.PICC_HaltA();
        // Stop encryption on PCD
            mfrc522.PCD_StopCrypto1();
            //Serial.println("Chon muc tao the moi:");
            //setkey_card = true;
            return;
        }
        //-------------------------------------

        value = String((char*)readbackblock);
        money = value.toInt();
        //Serial.println(money);

        // kiểm tra xem đang nằm ở chương trình chính hay không , nếu nằm ở ct chính thì hiển thị giá trị tiền trong thẻ ra
        if(mode == manHinhChinh)
        {
            //countToBreakHTsoTien=0;
            mode = modeMonneyInCard;
            bip(1,30);
        }

        //
        if (naptien == 1) 
        {
            naptien = 0;
            truongHopKhiGhiTien = 0;
            if (am == 1) {
                // am=0;     //gia tri tru tien
                if (giaSanPham*1000 <= money)
                {
                    money = money - giaSanPham*1000;
                    truongHopKhiGhiTien = 1;            //truong hop cho phep tru tien   
                    //Serial.println("thanh toan");
                    mode= camOn;
                }
                else if (giaSanPham*1000 > money)
                {
                    truongHopKhiGhiTien = 2;            //truong hop khong cho phep tru tien
                    //Serial.println("Khong du tien");
                    //lcd.setCursor(0,4);lcd.print("Ban khong du tien");
                    mode = modeThoatDocCard;
                }
            }
            else
            {
                 truongHopKhiGhiTien = 3;
                    money = money + _naptien;
                    mode = manHinhChinh;

            }
        }
        
        
        if(truongHopKhiGhiTien !=2)
        {
            String nap = String(money);
            nap.getBytes(bufferBlock, 16);
            writeBlock(block, bufferBlock);
            giaSanPham =0;

        }
        
       mfrc522.PICC_HaltA();
        // Stop encryption on PCD
        mfrc522.PCD_StopCrypto1();
    }  

}
    


//Đọc block đặc biệt
int readBlock(int blockNumber, byte arrayAddress[])
{
    int largestModulo4Number = blockNumber / 4 * 4;
    int trailerBlock = largestModulo4Number + 3;//determine trailer block for the sector
    //Kiểm tra xác thực trước
    byte status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, trailerBlock, &key, &(mfrc522.uid));
    if (status != MFRC522::STATUS_OK) {
        //Serial.print("PCD_Authenticate() failed (read): Key A Khong Dung");
       // Serial.println(mfrc522.GetStatusCodeName(status));
        unsigned long currentCard = millis();

        if (currentCard - prvCard >= intervalCard) {
            // save the last time you blinked the LED
            prvCard = currentCard;

            char buffer1[20];   //$R00001#
            sprintf(buffer1, "$%s%05d#", cm_faultCard.c_str(), 0);          //nếu đọc không phải là card đã xác thực thì thông báo lỗi
            Serial.println(buffer1);
            lcd.setCursor(0, 2);
            lcd.print("Chua xac thuc the");
        }


        return 3;//trả lại là số  "3" lỗi xác thực
    }
    //reading a block
    byte buffersize = 18;//we need to define a variable with the read buffer size, since the MIFARE_Read method below needs a pointer to the variable that contains the size... 
    status = mfrc522.MIFARE_Read(blockNumber, arrayAddress, &buffersize);//&buffersize is a pointer to the buffersize variable; MIFARE_Read requires a pointer instead of just a number
    
    if (status != MFRC522::STATUS_OK) {
        //Serial.print("MIFARE_read() failed: Khong doc duoc: ");
        //Serial.println(mfrc522.GetStatusCodeName(status));
        unsigned long currentMillis = millis();

        if (currentMillis - previousMillis >= interval) {
            // save the last time you blinked the LED
            previousMillis = currentMillis;
            char buffer1[20];   //$R00001#
            sprintf(buffer1, "$%s%05d#", cm_faultCard.c_str(), 0);
            Serial.println(buffer1);
             lcd.setCursor(0, 2);
            lcd.print("Chua xac thuc the");
        }
       
        return 4;//return "4" as error message
    }
    byte buffersize2 = 18;//we need to define a variable with the read buffer size, since the MIFARE_Read method below needs a pointer to the variable that contains the size... 
    boolean status2 = mfrc522.MIFARE_Read(blockIDCard, readbackblockPhone, &buffersize2);//&buffersize is a pointer to the buffersize variable; MIFARE_Read requires a pointer instead of just a number

    if (status2 != MFRC522::STATUS_OK) {       
        return 5;//return "4" as error message
    }
    
    phoneKH = String((char*)readbackblockPhone);
    //Serial.println(phoneKH);
    //Serial.println("block was read");
    return 0;
}

void hienThiSoTienTrongThe()
{
    lcd.clear();
    lcd.setCursor(0,0);lcd.print("So tien trong the:");
    char buffer1[20];   //$R00001#
    if(money>=1000000)
    {
        int tempnghin = money/1000;
        sprintf(buffer1, " %d.%03d.000 VND", tempnghin/1000,tempnghin%1000);
    }
    else 
    {
        //int tempnghin = money/1000;
        sprintf(buffer1, " %d.000 VND", money/1000);
    }
    
    lcd.setCursor(0,1);lcd.print(buffer1);
    //lcd.setCursor(7,1);lcd.print("VND");
    countToBreakHTsoTien++;
    if(countToBreakHTsoTien>=8) {mode = manHinhChinh; countToBreakHTsoTien=0;bip(1,50);}          //đoạn này để thoát về lại màn hình chính
}

//Write specific block    
int writeBlock(int blockNumber, byte arrayAddress[])
{
    //this makes sure that we only write into data blocks. Every 4th block is a trailer block for the access/security info.
    int largestModulo4Number = blockNumber / 4 * 4;
    int trailerBlock = largestModulo4Number + 3;//determine trailer block for the sector
    if (blockNumber > 2 && (blockNumber + 1) % 4 == 0) {//Serial.print(blockNumber);Serial.println(" is a trailer block:");
        return 2;
    }
    //Serial.print(blockNumber);
    //Serial.println(" is a data block:");

    //authentication of the desired block for access
    byte status = mfrc522.PCD_Authenticate(MFRC522::PICC_CMD_MF_AUTH_KEY_A, trailerBlock, &key, &(mfrc522.uid));
    if (status != MFRC522::STATUS_OK) {
        //Serial.print("PCD_Authenticate() failed: ");
        //Serial.println(mfrc522.GetStatusCodeName(status));
        char buffer1[20];   //$R00001#
        sprintf(buffer1, "$%s%05d#", cm_faultCard.c_str(), 0);
        Serial.println(buffer1);
        return 3;//return "3" as error message
    }

    //writing the block 
    status = mfrc522.MIFARE_Write(blockNumber, arrayAddress, 16);
    //status = mfrc522.MIFARE_Write(9, value1Block, 16);
    if (status != MFRC522::STATUS_OK) {
        char buffer1[20];   //$R00001#
        sprintf(buffer1, "$%s%05d#", cm_faultCard.c_str(), 0);
        Serial.println(buffer1);
        return 4;//return "4" as error message
    }
    //gui lenh lai PC
    switch (truongHopKhiGhiTien)
    {

    case 1:
        am = 0;
        //gui lenh da tru tien thanh cong
        char buffer[20];   //$R00001#
        sprintf(buffer, "$%s%05d#", cm_confirmMinusMoneyInCard.c_str(), giaSanPham / 1000);
        Serial.println(buffer);
        break;
    case 2:
        am = 0;
        char buffer1[20];   //$R00001#
        sprintf(buffer1, "$%s%05d#", cm_faultWhenCommand.c_str(), 0);
        Serial.println(buffer1);
        break;
    case 3:
        char buffer2[20];   //$R00001#
        sprintf(buffer2, "$%s%05d#", cm_confirmPlusMoneyInCard.c_str(), giaSanPham / 1000);
        Serial.println(buffer2);
        break;

    default:
        break;
    }

}
void thanhtoanThe()
{
    lcd.setCursor(0,2);lcd.print("Vui long dua the");
}
int countModeThoatdocCard=0;
void thoatdocCard()
{
    lcd.setCursor(0,4);lcd.print("Ban khong du tien");
    countModeThoatdocCard++;
    if(countModeThoatdocCard>8) {countModeThoatdocCard=0;mode = manHinhChinh;}
}
void nhapMatKhau()
{
   String num1 ="";
   boolean b_thoatHamNhapTien=false;
   lcd.clear();
    lcd.setCursor(0, 0);lcd.print("Admin:");
    while(1)
    {
        
	    char key = keypad.getKey();
	    if (key) {		
            switch (key)
			{
			    case NO_KEY:
				    break;

			    case '1': case '2': case '3': case '4':
			    case '5': case '6': case '7': case '8':
                    bip(1, 50);
                    num1 = num1 + key;
                    lcd.setCursor(0, 1);lcd.print("MK:");
                    lcd.setCursor(3, 1);
                    lcd.print(num1);
                    //hien thi number
                    break;	
                case 'R':
                    bip(1,50);
                    b_thoatHamNhapTien=true;

                    break;
                case 'C':
                    bip(1,50);
                    num1="";
                    lcd.clear();
                    lcd.setCursor(0, 0);lcd.print("Admin:");
                    
                    lcd.setCursor(0, 1);lcd.print("MK:");
                    lcd.setCursor(3, 1);
                    lcd.print(num1);
                    break;
			}
		}
        if(b_thoatHamNhapTien) 
        {
            if(num1.equals("12345")) 
            {
                mode = modeNhapTien;

            }

            else {
                mode = manHinhChinh;
                
            }
            break;
        }		
    }			
}
void nhapTien()
{

    String num1 ="";
    boolean b_thoatHamNhapTien=false;
    lcd.clear();
    lcd.setCursor(0,0);lcd.print("Nhap so tien:");
    while(1)
    {            
	    char key = keypad.getKey();
	    if (key) {		
            switch (key)
			{
			    case NO_KEY:
				    break;

			    case '1': case '2': case '3': case '4':
			    case '5': case '6': case '7': case '8': case '9': case '0':
                    bip(1, 50);
                    num1 = num1 + key;
                    lcd.setCursor(0, 1);lcd.print("Tien:");
                    lcd.setCursor(6, 1);
                    lcd.print(num1);
                    //hien thi number
                    break;	
                case 'R':
                    bip(1,50);
                    b_thoatHamNhapTien=true;

                    break;
                case 'C':
                    bip(1,50);
                    num1="";
                    lcd.clear();
                    lcd.setCursor(0,0);lcd.print("Nhap so tien:");
                    
                    lcd.setCursor(0, 1);lcd.print("Tien:");
                    lcd.setCursor(6, 1);
                    lcd.print(num1);
                    break;
			}
		}
        if(b_thoatHamNhapTien) 
        {
            b_chophepdocCard = true;
            naptien = 1;
            am=0;
            _naptien = num1.toInt();
            //Serial.println(_naptien);
            mode = docRFID;
            break;
        }		
    }

}
